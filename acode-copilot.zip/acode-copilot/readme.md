# Acode Copilot

Gemini-powered AI code completion for Acode.

Features:
- Inline ghost-text suggestions
- AI completion dropdown
- Tab to accept inline suggestions
- Escape to dismiss inline suggestions

This is an experimental personal-use plugin.