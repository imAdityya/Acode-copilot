# Acode Copilot

Experimental Gemini-powered autocomplete plugin for Acode.

Features:
- Inline ghost-text suggestions
- AI completion dropdown
- Tab to accept inline suggestions
- Escape to dismiss inline suggestions

This is an experimental personal-use prototype.
