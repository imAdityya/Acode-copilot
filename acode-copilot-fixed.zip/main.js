
"use strict";

const PLUGIN_ID = "mx.acode.copilot";
const GEMINI_MODEL = "gemini-2.5-flash";
const KEY_STORAGE = "mx.acode.copilot.geminiKey";

let destroyed = false;
let activeView = null;
let requestCounter = 0;
let debounceTimer = null;
let lastSuggestions = [];
let lastSnapshot = "";
let ghostField;
let setGhostEffect;
let completionStart;

function getCodeMirrorModule(name) {
  try {
    return acode.require(name);
  } catch {
    return null;
  }
}

async function requestGemini(apiKey, before, after) {
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey
      },
      body: JSON.stringify({
        systemInstruction: {
          parts: [{
            text:
              "You are an inline code autocomplete engine. " +
              "Return only JSON with this format: " +
              '{"suggestions":["code completion"]}. ' +
              "Return 1 to 3 concise code continuations. " +
              "Do not repeat the code before the cursor. " +
              "Do not include markdown fences or explanations."
          }]
        },
        contents: [{
          role: "user",
          parts: [{
            text:
              "Complete the code at <CURSOR>.\n" +
              "Text before cursor:\n" + before +
              "\n<CURSOR>\nText after cursor:\n" + after
          }]
        }],
        generationConfig: {
          responseMimeType: "application/json",
          temperature: 0.2,
          maxOutputTokens: 300
        }
      })
    }
  );

  const data = await response.json();

  if (!response.ok) {
    throw new Error(
      data.error?.message || `Gemini HTTP ${response.status}`
    );
  }

  const output = data.candidates?.[0]?.content?.parts
    ?.map(part => part.text || "")
    .join("");

  if (!output) return [];

  const result = JSON.parse(output);

  if (!Array.isArray(result.suggestions)) return [];

  return result.suggestions
    .filter(value => typeof value === "string")
    .map(value => value.replace(/\r\n/g, "\n"))
    .filter(value => value.trim())
    .slice(0, 3);
}

function readContext(view) {
  const position = view.state.selection.main.head;
  const document = view.state.doc;

  return {
    position,
    before: document.sliceString(
      Math.max(0, position - 4000),
      position
    ),
    after: document.sliceString(
      position,
      Math.min(document.length, position + 2000)
    )
  };
}

function clearGhost(view) {
  if (!view || !setGhostEffect) return;

  view.dispatch({
    effects: setGhostEffect.of(null)
  });
}

function createGhostWidget(Decoration, WidgetType) {
  return class GhostWidget extends WidgetType {
    constructor(text) {
      super();
      this.text = text;
    }

    eq(other) {
      return other.text === this.text;
    }

    toDOM() {
      const element = document.createElement("span");
      element.textContent = this.text;
      element.className = "acode-copilot-ghost";

      element.style.cssText = [
        "color:var(--cm-lineNumbers-foreground,#888)",
        "opacity:0.75",
        "white-space:pre-wrap",
        "pointer-events:none"
      ].join(";");

      element.setAttribute("aria-hidden", "true");
      return element;
    }

    ignoreEvent() {
      return true;
    }
  };
}

function setupEditor(apiKey) {
  const state = getCodeMirrorModule("@codemirror/state");
  const viewModule = getCodeMirrorModule("@codemirror/view");
  const autocomplete = getCodeMirrorModule("@codemirror/autocomplete");

  if (
    !state?.StateField ||
    !state?.StateEffect ||
    !viewModule?.EditorView ||
    !viewModule?.WidgetType ||
    !viewModule?.Decoration ||
    !viewModule?.ViewPlugin ||
    !autocomplete?.autocompletion ||
    !autocomplete?.startCompletion
  ) {
    throw new Error(
      "CodeMirror 6 APIs unavailable. Check your Acode version."
    );
  }

  const {
    StateField,
    StateEffect,
    EditorState
  } = state;

  const {
    EditorView,
    WidgetType,
    Decoration,
    ViewPlugin,
    keymap
  } = viewModule;

  const {
    autocompletion,
    startCompletion
  } = autocomplete;

  completionStart = startCompletion;
  setGhostEffect = StateEffect.define();

  const GhostWidget = createGhostWidget(Decoration, WidgetType);

  ghostField = StateField.define({
    create() {
      return {
        text: "",
        position: -1,
        decorations: Decoration.none
      };
    },

    update(value, transaction) {
      let next = value;

      if (
        transaction.docChanged ||
        transaction.selection ||
        transaction.effects.some(effect =>
          effect.is(setGhostEffect)
        )
      ) {
        next = {
          text: "",
          position: -1,
          decorations: Decoration.none
        };
      }

      for (const effect of transaction.effects) {
        if (!effect.is(setGhostEffect)) continue;

        const suggestion = effect.value;

        if (suggestion?.text && suggestion.position >= 0) {
          next = {
            text: suggestion.text,
            position: suggestion.position,
            decorations: Decoration.set([
              Decoration.widget({
                widget: new GhostWidget(suggestion.text),
                side: 1
              }).range(suggestion.position)
            ])
          };
        }
      }

      return next;
    },

    provide(field) {
      return EditorView.decorations.from(
        field,
        value => value.decorations
      );
    }
  });

  const completionSource = context => {
    if (!lastSuggestions.length) return null;

    const view = activeView;
    if (!view) return null;

    const position = context.pos;

    return {
      from: position,
      options: lastSuggestions.map((suggestion, index) => ({
        label:
          suggestion.split("\n")[0].slice(0, 100) ||
          "Continue code",
        detail: `Gemini suggestion ${index + 1}`,
        type: "text",

        apply(editor, completion, from, to) {
          editor.dispatch({
            changes: {
              from,
              to,
              insert: suggestion
            },
            selection: {
              anchor: from + suggestion.length
            }
          });

          lastSuggestions = [];
          lastSnapshot = "";
        }
      }))
    };
  };

  const completionLanguage = EditorState.languageData.of(() => [
    { autocomplete: completionSource }
  ]);

  const suggestionPlugin = ViewPlugin.fromClass(
    class {
      constructor(view) {
        this.view = view;
        this.schedule(view);
      }

      update(update) {
        if (
          update.docChanged ||
          update.selectionSet ||
          update.focusChanged
        ) {
          this.schedule(update.view);
        }
      }

      schedule(view) {
        clearTimeout(debounceTimer);

        const requestId = ++requestCounter;

        if (
          !view.hasFocus ||
          !view.state.selection.main.empty
        ) {
          lastSuggestions = [];
          clearGhost(view);
          return;
        }

        debounceTimer = setTimeout(async () => {
          if (destroyed || requestId !== requestCounter) return;

          const snapshot = readContext(view);
          const fingerprint =
            snapshot.before + "\u0000" + snapshot.after;

          if (fingerprint === lastSnapshot) return;
          lastSnapshot = fingerprint;

          try {
            const suggestions = await requestGemini(
              apiKey,
              snapshot.before,
              snapshot.after
            );

            if (destroyed || requestId !== requestCounter) return;
            if (activeView !== view) return;

            const current = readContext(view);

            if (
              current.position !== snapshot.position ||
              current.before !== snapshot.before ||
              current.after !== snapshot.after
            ) return;

            lastSuggestions = suggestions;

            view.dispatch({
              effects: setGhostEffect.of(
                suggestions.length
                  ? {
                      text: suggestions[0],
                      position: snapshot.position
                    }
                  : null
              )
            });

            if (suggestions.length) {
              completionStart(view);
            }
          } catch (error) {
            console.error("[Acode Copilot]", error);
          }
        }, 700);
      }

      destroy() {
        clearTimeout(debounceTimer);
        requestCounter++;
      }
    }
  );

  function acceptGhost(view) {
    const suggestion = view.state.field(ghostField, false);

    if (!suggestion?.text) return false;

    const position = suggestion.position;

    if (view.state.selection.main.head !== position) {
      return false;
    }

    view.dispatch({
      changes: {
        from: position,
        insert: suggestion.text
      },
      selection: {
        anchor: position + suggestion.text.length
      },
      effects: setGhostEffect.of(null)
    });

    lastSuggestions = [];
    lastSnapshot = "";
    return true;
  }

  return [
    ghostField,
    completionLanguage,
    autocompletion(),
    suggestionPlugin,
    keymap.of([
      {
        key: "Tab",
        run(view) {
          return acceptGhost(view);
        }
      },
      {
        key: "Escape",
        run(view) {
          const suggestion = view.state.field(ghostField, false);

          if (!suggestion?.text) return false;

          clearGhost(view);
          lastSuggestions = [];
          return true;
        }
      }
    ])
  ];
}

acode.setPluginInit(
  PLUGIN_ID,
  async () => {
    destroyed = false;

    const savedKey = localStorage.getItem(KEY_STORAGE);
    const enteredKey = savedKey ||
      window.prompt("Enter your Gemini API key:");

    if (!enteredKey?.trim()) {
      acode.toast("Gemini API key required.");
      return;
    }

    const apiKey = enteredKey.trim();

    // For personal testing only; browser storage is not secure storage.
    localStorage.setItem(KEY_STORAGE, apiKey);

    try {
      const manager = editorManager;
      const view = manager?.editor;

      if (!view || !manager.isCodeMirror) {
        acode.toast(
          "This prototype requires the CodeMirror 6 editor."
        );
        return;
      }

      activeView = view;

      const extension = setupEditor(apiKey);

      view.dispatch({
        effects: getCodeMirrorModule(
          "@codemirror/state"
        ).StateEffect.appendConfig.of(extension)
      });

      acode.toast("Acode Copilot initialized.");
    } catch (error) {
      console.error("[Acode Copilot]", error);
      acode.toast(`Copilot initialization failed: ${error.message}`);
    }
  }
);
